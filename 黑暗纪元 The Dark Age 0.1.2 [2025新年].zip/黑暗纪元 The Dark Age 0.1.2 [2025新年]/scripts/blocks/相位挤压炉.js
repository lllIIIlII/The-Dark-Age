const library = require("base/library");
const myliquids = require("HJliquids");
const myitems = require("HJitems");
const 相位挤压炉 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "相位挤压炉", [
  {
    input: {
      items: ["coal/7","blast-compound/1"],     
      liquids: ["water/1.9"],
      power: 8.8,
    },
    output: {
      items: ["graphite/4"],
    },
    craftTime: 7,
  }, 
  {
    input: {
      items: ["coal/14","黑暗纪元-洛德合金/1","黑暗纪元-空间节点/1"],     
      liquids: ["water/3"],
      power: 11.8,
    },
    output: {
      items: ["graphite/7"],
    },
    craftTime: 5.5,
  },
  {
    input: {
      items: ["titanium/6","blast-compound/1"],     
      liquids: ["oil/1.12"],
      power: 16.9,
    },
    output: {
      items: ["plastanium/4"],
    },
    craftTime: 7,
  },
  {
    input: {
      items: ["titanium/15","黑暗纪元-洛德合金/1","黑暗纪元-空间节点/1"],     
      liquids: ["oil/2.56"],
      power: 20,
    },
    output: {
      items: ["plastanium/8"],
    },
    craftTime: 6.9,
  },
  {
    input: {
      items: ["coal/8","sand/6","blast-compound/1"],     
      power: 9.9,
    },
    output: {
      items: ["silicon/7"],
    },
    craftTime: 8.8,
  },
  {
    input: {
      items: ["coal/17","sand/12","黑暗纪元-洛德合金/1","黑暗纪元-空间节点/1"],     
      power: 13.5,
    },
    output: {
      items: ["silicon/10"],
    },
    craftTime: 10,
  },
]);