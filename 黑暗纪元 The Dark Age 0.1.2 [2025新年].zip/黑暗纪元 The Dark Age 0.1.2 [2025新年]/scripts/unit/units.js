const lib = require("base/HJlib");
const my = require("base/items");
const ability = require("base/ability");

function newUnit(name, unitType, cons) {
	const u = extend(UnitType, name, cons || {});
	u.constructor = () => new unitType.create();
	return exports[name] = u;
}
exports.newUnit = newUnit;
function specialUnit(name, unitType, cons, cons2) {
	const u = extend(UnitType, name, cons || {});
	let id;
	u.constructor = () => extend(unitType, cons2 || {
		classId() {
			return id
		}
	});
	id = EntityMapping.register(lib.modName + name, u.constructor);
	return exports[name] = u;
}
exports.specialUnit = specialUnit;
function newUnitList(name, unitType, num, cons) {
	for (let i = 1; i <= num; i++) newUnit(name + i, unitType, cons);
}

function immunities(u) {
	u.immunities.addAll(StatusEffects.burning, StatusEffects.melting, StatusEffects.blasted, StatusEffects.wet, StatusEffects.freezing, StatusEffects.sporeSlowed, StatusEffects.slow, StatusEffects.tarred, StatusEffects.muddy, StatusEffects.sapped, StatusEffects.electrified, StatusEffects.unmoving, status.保护, status.攻速提升, status.过载, status.护佑, status.警惕, status.狂暴, status.凝铠, status.轻盈, status.闪耀, status.伤害提升, status.神圣, status.生命提升, status.修复, status.再生, status.爆燃, status.腐化, status.寂灭, status.禁锢, status.空间混乱, status.溃解, status.扭转, status.瘫痪, status.污染, status.消散, status.虚弱, status.延迟, status.疑惑, status.致盲, status.超相, status.磁化, status.复分解, status.破防, status.献祭);
}
exports.immunities = immunities;
