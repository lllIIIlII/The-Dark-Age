// 导入必要的 Java 类
const PowerTurret = Packages.mindustry.world.blocks.defense.turrets.PowerTurret;
const BulletType = Packages.mindustry.entities.bullet.BulletType;
const Unit = Packages.mindustry.entities.type.Unit;
const Items = Packages.mindustry.content.Items;
const Category = Packages.mindustry.world.BlockCategory;

// 定义秒杀炮台类
const InstaKillTurret = Java.extend(PowerTurret, {
    // 构造函数
    init: function(name) {
        this.super$(name);
        
        // 基础属性
        this.reload = 30; 
        this.range = 25 * 8; 
        this.rotateSpeed = 10; 
        this.health = 1200; 
        this.size = 3; 
        
        // 子弹配置
        this.shootType = new BulletType();
        this.shootType.speed = 10;
        this.shootType.lifetime = 60; 
        
        // 子弹命中时秒杀单位
        this.shootType.hit = function(entity) {
            if (entity instanceof Unit) {
                entity.kill();
            }
        };
        
        // 建造所需资源
        this.requirements = [Items.copper, 100];
        this.category = Category.turret;
    }
});

// 注册炮台
const instaKillTurret = new InstaKillTurret("insta-kill-turret");
exports.blocks.add(instaKillTurret);