MapResizeDialog.minSize = 16;
MapResizeDialog.maxSize = 2048;
Vars.renderer.minZoom = 0.1;
Vars.renderer.maxZoom = 100;
ControlPathfinder.showDebug = false;//广寻显示，测试再开
require("HJitems");
require("HJliquids");
require("blocks/前线指挥中心");
require("blocks/相位挤压炉");
require("blocks/临时核心");
require("planets/普兰则尔");
require("blocks/测试")

//以下代码借鉴于模组：蔚蓝行星
Events.on(EventType.ClientLoadEvent, cons(e => {
var dialogo = new BaseDialog("[white]黑暗纪元\nThe Dark Age");
	dialogo.buttons.button("@close", run(() => {
	dialogo.hide()
	})).size(210, 64);
dialogo.cont.pane(table => {
table.add(Core.bundle.get("mod.黑暗纪元.update")).left().labelAlign(Align.left).row();
table.image(Core.atlas.find("logo")).left().size(600, 100).pad(3).row();

table.add("[#00FFFF]模组：黑暗纪元 The Dark Age 0.1.4\n[white]建议过了行星发射终端再来游玩此模组\n如果发现游戏内名称为英文，请重新调整语言").left().growX().wrap().pad(4).labelAlign(Align.left).row();
table.add("[white]——————————\n[#00FFFF]v0.1.4更新内容:\n[white]部分地图修改\n部分工厂贴图修改\n部分炮台特效修改\n部分单位特效修改\n地图：铁线三角洲重做\n单位：神佑  能量球攻击频率降低\n单位：尘落  添加亡语\n炮台：消防装置  添加矿渣弹药\n炮台：牵引  伤害提高\n新增地图：突袭\n新增地板\n新增单位：威严  等级：T6\n新增单位：天仙  等级：T6\n新增单位：凄光  等级：T6\n新增文案"
).left().growX().wrap().width(580).maxWidth(580).pad(4).labelAlign(Align.left).row();

	}).grow().center().maxWidth(600)
	 dialogo.cont.button("关注up\n[#00FFFF]Supernova-68",run(() => {
               Core.app.openURI("https://space.bilibili.com/1908743845?spm_id_from=333.1007.0.0");
             })).size(200,70).pad(2);
             dialogo.show();
}))
