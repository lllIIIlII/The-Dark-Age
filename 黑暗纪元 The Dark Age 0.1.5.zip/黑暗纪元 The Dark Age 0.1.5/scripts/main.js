MapResizeDialog.minSize = 16;
MapResizeDialog.maxSize = 2048;
Vars.renderer.minZoom = 0.1;
Vars.renderer.maxZoom = 100;
ControlPathfinder.showDebug = false;//广寻显示，测试再开
require("HJitems");
require("HJliquids");
require("blocks/相位挤压炉");
require("blocks/临时核心");
require("blocks/前线指挥中心");
require("planets/普兰则尔")

//以下代码借鉴于模组：蔚蓝行星
Events.on(EventType.ClientLoadEvent, cons(e => {
var dialogo = new BaseDialog("[white]黑暗纪元\nThe Dark Age");
	dialogo.buttons.button("@close", run(() => {
	dialogo.hide()
	})).size(210, 64);
dialogo.cont.pane(table => {
table.add(Core.bundle.get("mod.黑暗纪元.update")).left().labelAlign(Align.left).row();
table.image(Core.atlas.find("logo")).left().size(600, 100).pad(3).row();

table.add("[#00FFFF]模组：黑暗纪元 The Dark Age 0.1.5\n[white]——————[red]注意事项[white]——————\n请不要用全球占领的存档\n建议过了行星发射终端再来游玩此模组\n如果发现游戏内名称为英文，请重新调整语言").left().growX().wrap().pad(4).labelAlign(Align.left).row();
table.add("[white]——————[gold]更新内容[white]——————\n[#00FFFF]v0.1.5:[white]\n部分钻头修改\n部分物流运输修改\n部分单位贴图重画\n部分炮台解锁条件更改\n血光：重做\n穹顶：攻速降低，射程缩短\n原版爬虫：自爆添加爆炸穿透\n守望：闪电伤害降低，闪电数量减少\n霜雪：大雪花爆炸伤害大幅增加\n九幽：暗能钢弹药  攻击破片更集中\n电光：巨浪合金弹药  钻头闪电伤害提升\n啄木鸟：洛德合金弹药  增加建筑穿透，建筑专攻提升\n剑仙：巨剑伤害大幅提升\n新增地图：清扫  普兰则尔主线结束"
).left().growX().wrap().width(580).maxWidth(580).pad(4).labelAlign(Align.left).row();

	}).grow().center().maxWidth(600)
	 dialogo.cont.button("关注up\n[#00FFFF]Supernova-68",run(() => {
               Core.app.openURI("https://space.bilibili.com/1908743845?spm_id_from=333.1007.0.0");
             })).size(200,70).pad(2);
             dialogo.show();
}))
