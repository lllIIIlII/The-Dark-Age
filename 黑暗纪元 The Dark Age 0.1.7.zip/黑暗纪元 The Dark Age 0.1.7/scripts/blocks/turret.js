const library = require("base/library");
const myliquids = require("HJliquids");
const myitems = require("HJitems");

"unitSort": "strongest",
	"size":7,
	"health":14440,
	"ammoPerShot":10,
	"range":712,
	"reload":90,
	"recoil":5,
	"inaccuracy":0,
	"rotatespeed":7,
	"maxAmmo":400,
	"targetGround": true,
	"targetAir": true,
	"canOverdrive": false,
	"shootSound":"shootAltLong",
	"liquidCapacity": 48,
	"consumes": {
	"power": 198.9,
	"coolant": {
	"amount": 0.6,
	"optional": true
	}
	},
"lead/3210"
	"钴/1900"
	"钴钢/500"
	"钢/1950"
	"贫铀/1565"
	"plastanium/1700"
	"metaglass/3000"
	
const zmn = new ItemTurret("啄木鸟");
exports.zmn = zmn;
Object.assign(zmn,{
	reload: 90,
	range: 712,
	shootCone: 1,
	health: 360,
	inaccuracy: 1,
	rotateSpeed: 1.7,
	alwaysUnlocked: true,
	//buildVisibility: BuildVisibility.shown,
	category: Category.turret,
	requirements: ItemStack.with(
		item.lead, 3120,
		item.钴, 1900,
		item.钴钢, 500,
		item.钢, 1950,
		item.贫铀, 1565,
		item.plastanium, 1700,
		item.metaglass, 3000,
	)
})
guard.ammo(
	item.nickel, Object.assign(new BasicBulletType(3, 9),{
		width: 2,
		height: 9,
		lifetime: 60,
		ammoMultiplier: 3,
	}),
	Items.graphite, Object.assign(new BasicBulletType(3, 15),{
		width: 2,
		height: 12,
		reloadMultiplier: 0.6,
		ammoMultiplier: 6,
		lifetime: 60,
	})
)