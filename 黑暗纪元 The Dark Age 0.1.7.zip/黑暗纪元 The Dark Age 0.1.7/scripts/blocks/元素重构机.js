const library = require("base/library");
const myliquids = require("HJliquids");
const myitems = require("HJitems");
const 元素重构机 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "元素重构机", [
  {
    input: {
      items: ["graphite/5","copper/5"],
      power: 50,
    },
    output: {
      items: ["黑暗纪元-钴/5"],
    },
    craftTime: 20,
  }, 
  {
    input: {
      items: ["graphite/5","copper/5"],
      power: 75,
    },
    output: {
      items: ["黑暗纪元-铁/5"],
    },
    craftTime: 20,
  }, 
  {
    input: {
      items: ["graphite/8","copper/10"],
      power: 100,
    },
    output: {
      items: ["黑暗纪元-铀/3"],
    },
    craftTime: 45,
  },
]);